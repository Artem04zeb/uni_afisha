<?php
session_start();

//assets
require_once 'assets/blocks_html/blocks.php';
require_once 'assets/sql/filling_of_events.php';
require_once 'assets/sql/events_for_orgs.php';

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="vieport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style/css.css?x=1">
    <link rel="stylesheet" href="assets/style/small_screen.css?x=1">

    <title>MISIS АФИША</title>
</head>

<!-- HEADER -->
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

        <!--LOGO-->
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
            <span class="fs-3">MISIS АФИША</span>
        </a>

        <!--NAVIGATION-->
        <ul class="nav nav-pills">
            <li class="nav-item">
                <?php
                if($_SESSION['user']){
                    if($_SESSION['user'] == 'organizer'){
                        echo '<span class="fs-6 header_txt">Выполнен вход с правами организатора</span>';
                    }
                    if($_SESSION['user'] == 'admin'){
                        echo '<span class="fs-6 header_txt">Выполнен вход с правами администратора</span>';

                        echo '
                    <a href="admin.php">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="">
                        Комната админа
                    </button>
                    </a>';
                    }
                    echo '
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                            Выйти
                        </button>';
                }
                else{
                    echo '
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                            Зарегистрироваться
                        </button>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                            Войти
                        </button>
                        ';
                }
                ?>
            </li>
        </ul>

    </header>
</div>

<body>

<section class="border p-4 container text-center mb-4 rounded-5">

    <!--SESSION MESSAGE-->
    <p>
        <?php
        if ($_SESSION['message']){
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
        ?>
    </p>
    <span class="fs-2 under_table_month">2023</span>
    <div class="controls">
        <button id="btnPrev" class="btn">Предыдущий месяц</button>
        <button id="btnNext" class="btn">Следующий месяц</button>
    </div>
    <br><br>
    <div class="slider" id="slider">
        <?php
        $cell = '<div class="product"></div>';
        $monthes = [1 => 'Январь',
            2 => 'Февраль',
            3 => 'Март',
            4 => 'Апрель',
            5 => 'Май',
            6 => 'Июнь',
            7 => 'Июль',
            8 => 'Август',
            9 => 'Сентябрь',
            10 => 'Октябрь',
            11 => 'Ноябрь',
            12 => 'Декабрь'];
        $monthes_ending = [1 => 'января',
            2 => 'февраля',
            3 => 'марта',
            4 => 'апреля',
            5 => 'мая',
            6 => 'июня',
            7 => 'июля',
            8 => 'августа',
            9 => 'сентября',
            10 => 'октября',
            11 => 'ноября',
            12 => 'декабря'];
        $days_in_months = [31,28,31,30,31,30,31,31,30,31,30,31];
        $first_day = [6, 2, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4];

        for ($month = 1; $month  < 13; $month++){
            echo '<div class="event_table">
                
                <span class="fs-3 under_table_month">'.$monthes[$month].'</span>
                
                <br><br>    
        
                <div class="events_all">
        
                    <div class="products">
                        <div class="product week_day">ПН</div>
                        <div class="product week_day">ВТ</div>
                        <div class="product week_day">СР</div>
                        <div class="product week_day">ЧТ</div>
                        <div class="product week_day">ПТ</div>
                        <div class="product week_day">СБ</div>
                        <div class="product week_day">ВС</div>';
                        for($i = 0; $i < $first_day[$month-1]; $i++){
                            echo $cell;
                        }
                        for($i = 0; $i < $days_in_months[$month-1]; $i++){
                            echo "<input class='product product_live ";
                            if (in_array($i+1, $new_days_with_events[$month])){
                                echo 'there_is_event_today';
                            }
                            echo "'type='button' value='", ($i+1),"' onclick='viewDiv(" . '"div'.($i+1) . '_'. $month  .'"' . ")'>";

                        }
                    echo '</div>';

                    echo '<div class="events_information">';

                        for($i = 1; $i < $days_in_months[$month-1]; $i++){
                            echo
                                '<div id="div' . $i . '_'. $month . '" class="product_info not_hovered">';
                            echo '<span class="fs-4">События на '. $i . ' '. $monthes_ending[$month] .':</span>';
                            if (is_array($new_events[$month]) || is_object($new_events[$month]))
                            {
                                foreach ($new_events[$month] as $key => $value){
                                    if($i == $value['day']){
                                        echo '<div class="event_info">' .

                                            '<h4>' . $value['title'] . ': </h4>' . // Title
                                            '<b>Организатор: </b>' . $value['organization'] . '<br>' . // Organization
                                            '<b>Начало: </b>'.substr($value['time'],0,5).'<br>' . // time
                                            '<b>Окончание: </b>'. substr($value['duration'], 0, 5) . '<br>' . // Duration
                                            '<b>Место проведения: </b>' . $value['place'] . '<br>' . // Place
                                            nl2br($value['description'], false) . '<br>' . // Description
                                            '</div><hr>';

                                    }
                                }
                            }
                            echo
                            '</div>';
                        }
                    echo'</div>';

                echo '</div>';
            echo '</div>';
        }
        ?>
    </div>

    <!--CheckBox of Events-->
    <?php
    //      ADD EVENT BUTTON
    if ($_SESSION['user']){
        echo '
                    <div class="under_header">         
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal4">
                            Создать событие
                        </button>
                    </div>
                    ';
    }
    //      DELETE EVENT IF ADMIN
    if ($_SESSION['user'] == 'admin'){
        echo '
                <form action="assets/sql/delete_event.php" method="post">
                    <button class="btn btn-primary" style="display: flex; margin-bottom: 1em;" type="submit">Удалить событие</button>';
        foreach ($events_before_fixing as $value) {
            echo '
                            <div style="display: flex; border: black 1px solid; padding: 10px; margin-bottom: 20px;" >
                                <input type="checkbox" class="large_checkbox form-check-input" name="' . $value['event_id'] . '" value="' . $value['event_id'] . '">
                                <div style="padding: 20px; text-align: left; margin-left: 10px; class="check_box">
                                    <span>' . $value['title'] . ', ' . $value['org_id'] . '</span>
                                    <br>
                                </div>
                            </div>';
        }
        echo '</form>';
    }
    //      DELETE EVENT IF ORGANIZER
    if ($_SESSION['user'] == 'organizer'){
        echo '
                <form action="assets/sql/delete_event.php" method="post">
                    <button class="btn btn-primary" style="display: flex; margin-bottom: 1em;" type="submit">Удалить мероприятие</button>';
        foreach ($events_for_orgs as $value) {
            echo '
                <div style="display: flex; border: black 1px solid; padding: 10px; margin-bottom: 20px;" >
                    <input type="checkbox" class="large_checkbox form-check-input" name="' . $value['event_id'] . '" value="' . $value['event_id'] . '">
                    <div style="padding: 20px; text-align: left; margin-left: 10px; class="check_box">
                        <span>' . $value['day'] . '.' . date('m') . ' ' . $value['title'] . '</span>
                        <br>    
                        <span>' . substr($value['time'], 0, 5) . '</span>
                    </div>
                </div>
                        ';
        }
        echo '</form>';
    }

    ?>
</section>

    <?php echo $footer1; ?>
</body>


<?php
echo $modal_register;
echo $modal_autorization;
echo $modal_exit;
echo $modal_add_event;
?>
</html>

<script src="assets/scripts/main.js?"></script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
