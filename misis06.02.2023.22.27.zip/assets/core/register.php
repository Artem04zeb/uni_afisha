<?php
session_start();

require_once 'connect.php';

$email = $_POST['email'];
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$organization = $_POST['organization'];
if (strlen($_POST['password1']) < 7  or strlen($_POST['password2']) < 7){
    $_SESSION['message'] = 'Слишком короткий пароль';
}
elseif($_POST['password1'] != $_POST['password2']){
    $_SESSION['message'] = 'Пароли не сопадают';
}
else{
//    OKEY, ALL IS DOWNLOADED
    $email = $_POST['email'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $org = $_POST['organization'];
    $password = password_hash($_POST['password1'], PASSWORD_DEFAULT); // md5();


    if (!mysqli_query($connect, "INSERT INTO `requests` (`id`, `email`, `fname`, `lname`, `organization`, `password`) 
    VALUES (NULL, '$email', '$fname', '$lname', '$org', '$password')")){
        $_SESSION['message'] = 'Ошибка при загрузке данных';
    }
    else{
        $_SESSION['message'] = 'Заявка на регистрацию отправлена успешно! Заявка будет подтверждена в течение суток.
        <br>Ведутся работы по ускорению процесса!';
    }
}
header('Location: ../../index.php');