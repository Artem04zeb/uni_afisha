<?php

session_start();

require_once 'connect.php';

$email = $_POST['email'];
$password = $_POST['password']; // md5()

$check = mysqli_query($connect, "SELECT * FROM `organizers`WHERE email='$email'");
$ar = mysqli_fetch_all($check, 1);
if(mysqli_num_rows($check) > 0){
    if(password_verify($password, $ar[0]['password'])){
        if ($ar[0]['organization'] == 'admin'){
            $_SESSION['user'] = 'admin';
        }
        else{
            $_SESSION['user'] = 'organizer';
            $_SESSION['id'] = $ar[0]['id'];
            $_SESSION['organization']= $ar[0]['organization'];
        }
    }
    else{
        $_SESSION['message'] = 'Неверный логин или пароль';
    }
}

//echo '<pre>';
//echo($_SESSION['user']);
//echo '</pre>';
header('Location: ../../index.php');