<?php
session_start();
require_once(__DIR__ . '/../core/connect.php');

$title = $_POST['title'];
$time = $_POST['time'];
$duration = $_POST['duration'];
$description = $_POST['description'];
$day = substr($_POST['date'], 8, 2);
$month = substr($_POST['date'], 5, 2);
$place = $_POST['place'];

$org_id = $_SESSION['id'];
$organization = $_SESSION['organization'];

echo '<pre>';
print_r($_POST);
echo '</pre>';

echo '<h2>' . $description. '</h2>';

if (!mysqli_query($connect, "INSERT INTO `events`(`event_id`, `time`, `day`, `org_id`, `description`, `title`, `month`, `duration`, `organization`, `place`)
VALUES (NULL,'$time','$day','$org_id','$description','$title','$month','$duration','$organization','$place')")){
    $_SESSION['message'] = 'ERROR TO ADD';
}

header('Location: ../../index.php');