<?php
require_once(__DIR__ . '/../core/connect.php');

$orgs = mysqli_query($connect, "SELECT * FROM `organizers`");
$orgs = mysqli_fetch_all($orgs, 1);
$orgs = array_slice($orgs, 1);