<?php
require_once(__DIR__ . '/../core/connect.php');


$events_before_fixing = mysqli_query($connect, "SELECT * FROM `events` ORDER BY month ASC");
$events_before_fixing = mysqli_fetch_all($events_before_fixing, 1);

$new_events = array();

$new_days_with_events = [1 => [],
                        2 => [],
                        3 => [],
                        4 => [],
                        5 => [],
                        6 => [],
                        7 => [],
                        8 => [],
                        9 => [],
                        10 => [],
                        11 => [],
                        12 => []];

foreach ($events_before_fixing as $value){
    if(array_key_exists($value['month'], $new_events)){
        array_push($new_events[$value['month']], $value);
    }
    else{
        $new_events[$value['month']] = array();
        array_push($new_events[$value['month']],  $value);
    }
}

foreach ($new_events as $key => $events) {
    foreach ($events as $event){
        array_push($new_days_with_events[$key], $event['day']);
    }
}

//echo '<pre>';
//print_r($new_events);
//echo '</pre>';
