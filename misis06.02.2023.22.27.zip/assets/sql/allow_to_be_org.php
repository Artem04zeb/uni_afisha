<?php
require_once(__DIR__ . '/../core/connect.php');

foreach ($_POST as $value){
    $sql = mysqli_query($connect, "SELECT * FROM `requests` WHERE id = '$value'");
    $sql = mysqli_fetch_all($sql, 1)[0];
    $id = $sql['id'];
    $fname = $sql['fname'];
    $lname = $sql['lname'];
    $password = $sql['password'];
    $email = $sql['email'];
    $organization = $sql['organization'];
    if(mysqli_query($connect, "INSERT INTO `organizers`(`id`, `email`, `password`, `fname`, `lname`, `organization`) VALUES (NULL,'$email','$password','$fname','$lname','$organization')")){
        mysqli_query($connect, "DELETE FROM `requests` WHERE id = '$value'");
    }
}
header('Location: ../../admin.php');