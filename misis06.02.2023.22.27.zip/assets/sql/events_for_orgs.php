<?php
session_start();

require_once(__DIR__ . '/../core/connect.php');
$id = $_SESSION['id'];

$events_for_orgs = mysqli_query($connect, "SELECT * FROM `events` WHERE org_id = '$id'");
$events_for_orgs = mysqli_fetch_all($events_for_orgs, 1);


