<?php

$header1 = '<div class="container">
        <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
                <span class="fs-4">Misis network</span>
            </a>

            <ul class="nav nav-pills">
                <li class="nav-item">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                    Зарегистрироваться
                </button>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                    Войти
                </button>
                <button type="button" class="btn btn-primary    " data-bs-toggle="modal" data-bs-target="#exampleModal3">
                    Выйти
                </button>
                </li> 
            </ul>
        </header>
    </div>';


$footer1 = '<section class="">

      <footer class="text-center text-lg-start bg-light text-muted">

        <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.2);">
          
          <div class="container  p-4">
                    <span class="fs-5">MISIS АФИША - Афиша всех мероприятий университета МИСИС.
                                Все без регистрации могут смотреть расписание.
                                <br>Если вы организатор - зарегистрируйтесь, чтобы создавать мероприятия.
                                <br>Сайт тестируется, любые вопросы, жалобы и рекомендации принимаются в мой телеграмм.
                    </span>

          </div>
            [FULL Разработка: Зебелян Артём] <br>
            TELEGRAM: 
              <span class="text-reset link fw-bold" >Goodzone_z</span>
                      <br>  
            © 2023 Copyright:
            <a class="text-reset link fw-bold" href="https://www.misos.site/">MISOS.SITE</a>
        </div>

      </footer>

    </section>';


$modal_exit = '
<div class="modal modal_author fade" id="exampleModal3" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вы действительно хотите выйти?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="assets/core/logout.php" method="post">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" aria-label="Close"  data-bs-dismiss="modal">Нет</button>
                            <button type="submit" class="btn btn-primary">Да</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>

';

$modal_register = '
<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Регистрация</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="assets/core/register.php" method="post">

                        <input name="email" type="email" class="form-control" aria-describedby="emailHelp" placeholder="email">
                        <input name="fname" type="text" class="form-control" placeholder="Имя">
                        <input name="lname" type="text" class="form-control" placeholder="Фамилия">
                        <input name="organization" type="text" class="form-control" placeholder="Организация">
                        <input name="password1" type="password" class="form-control" placeholder="Пароль">
                        <input name="password2" type="password" class="form-control" placeholder="Подтвердите пароль">

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
';


$modal_autorization = '
<div class="modal modal_author fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Вход</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="assets/core/login.php" method="post">
                        <input name="email" type="email" class="form-control" aria-describedby="emailHelp" placeholder="email">
                        <input name="password" type="password" class="form-control" placeholder="Пароль">

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Войти</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
';


$modal_add_event = '
<div class="modal modal_author fade" id="exampleModal4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Добавить мероприятие</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="assets/sql/sql_add.php" class="add_event_modal" method="post">
                        <label for="exampleInputPassword1" class="add_event_modal_item">Название меропрития</label>
                        <input type="text" class="form-control add_event_modal_item" name="title" placeholder="Игра в мафию">

                        <label class="add_event_modal_item">Место проведения</label>
                        <input type="text" class="form-control add_event_modal_item" name="place" placeholder="Холл Б корпуса, 1 этаж">

                        <label for="exampleInputPassword1" class="add_event_modal_item">Начало  </label>
                        <input type="time" class="form-control add_event_modal_time add_event_modal_item" name="time">
                        
                        <label for="exampleInputPassword1" class="add_event_modal_item">Продолжительность  </label>
                        <input type="time" class="form-control add_event_modal_time add_event_modal_item" name="duration">

                        <label for="exampleInputPassword1" class="add_event_modal_item">Дата События</label>
                        <input type="date" name="date" min="' . date('Y') .  '-'. date('m') . '-01' . '"
                               max="' . date('Y') . '-12-31">
                         
                        <label for="exampleInputPassword1" class="label_for_text">Введите описание</label>
                        <textarea name="description" class="form-control add_event_modal_description"></textarea>
                        <div class="modal-footer" >
                            <button type="submit" class="btn btn-primary">Создать</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
';