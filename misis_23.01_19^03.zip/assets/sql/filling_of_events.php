<?php
require_once(__DIR__ . '/../core/connect.php');

// Create array of events, where key = time, value = array(weekday, name of event)
// This array is used to fill table in index page
//
// $link - connect link to db
// $events - filing array

$events_before_fixing = mysqli_query($connect, "SELECT * FROM `events` ORDER BY time ASC");
$events_before_fixing = mysqli_fetch_all($events_before_fixing, 1);

$events = array();
$days_with_events = array();
foreach ($events_before_fixing as $value) {
    if (array_key_exists(substr($value['time'], 0, 5), $events)) { // если существует
        //                                                                  время, то добавь мероприятие на это время
        array_push($events[substr($value['time'], 0, 5)],
            array($value['day'], $value['title'], $value['text']));
    } else { // иначе, создай такое время и уже потом добавь мероприятие
        $events[substr($value['time'], 0, 5)] = array();
        array_push($events[substr($value['time'], 0, 5)],
            array($value['day'], $value['title'], $value['text']));
    }
    if (!in_array($value['day'], $days_with_events)){
        array_push($days_with_events, $value['day']);
    }
}
