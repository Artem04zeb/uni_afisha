<?php

require_once(__DIR__ . '/../core/connect.php');


foreach ($_POST as $item) {
    if (!mysqli_query($connect, "DELETE FROM `events` WHERE event_id = $item ")){
        $_SESSION['error_to_delete'] = 'ERROR TO DELETE';
    }
}
header('Location: ../../index.php');