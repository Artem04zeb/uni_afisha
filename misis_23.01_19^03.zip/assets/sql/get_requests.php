<?php
require_once(__DIR__ . '/../core/connect.php');

$requests = mysqli_query($connect, "SELECT * FROM `requests`");
$requests = mysqli_fetch_all($requests, 1);