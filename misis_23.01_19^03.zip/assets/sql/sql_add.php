<?php
session_start();
require_once(__DIR__ . '/../core/connect.php');

$time = $_POST['time'];
$org_id = $_SESSION['id'];
$text = $_POST['text'];
$title = $_POST['title'];
$day = substr($_POST['date'], 8, 2);


if (!mysqli_query($connect, "INSERT INTO `events` (`event_id`, `time`, `day`, `org_id`, `text`, `title`)
VALUES (NULL, '$time', '$day', '$org_id', '$text', '$title')")){
    $_SESSION['error_to_add'] = 'ERROR TO ADD';
}

header('Location: ../../index.php');