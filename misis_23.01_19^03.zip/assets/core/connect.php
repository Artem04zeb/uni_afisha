<?php
// LOCALHOST
$hostname = 'localhost';
$username ='root';
$password = '';
$database = 'events';

// SERVER
//$hostname = 'localhost';
//$username ='u1848919_root';
//$password = 'vC40THq7anN0W5rC';
//$database = 'u1848919_default';

$connect = mysqli_connect($hostname, $username, $password, $database);
if (!$connect){
    die('<br>MESSAGE FROM FILE: ERROR DUE CONNECT');
}
else{
    mysqli_set_charset($connect, 'utf8');
}
