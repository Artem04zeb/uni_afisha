<?php
session_start();

//assets
require_once 'assets/blocks_html/blocks.php';
require_once 'assets/sql/filling_of_events.php';
require_once 'assets/sql/events_for_orgs.php';

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="vieport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style/css.css">
    <link rel="stylesheet" href="assets/style/small_screen.css">

    <title>MISIS АФИША</title>
</head>

<!-- HEADER -->
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

        <!--LOGO-->
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
            <span class="fs-3">MISIS АФИША</span>
        </a>

        <!--NAVIGATION-->
        <ul class="nav nav-pills">
            <li class="nav-item">
                <?php
                if($_SESSION['user']){
                    if($_SESSION['user'] == 'organizer'){
                        echo '<span class="fs-6 header_txt">Выполнен вход с правами организатора</span>';
                    }
                    if($_SESSION['user'] == 'admin'){
                        echo '<span class="fs-6 header_txt">Выполнен вход с правами администратора</span>';

                        echo '
                    <a href="admin.php">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="">
                        Комната админа
                    </button>
                    </a>';
                    }
                    echo '
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                            Выйти
                        </button>';
                }
                else{
                    echo '
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal1">
                            Зарегистрироваться
                        </button>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal2">
                            Войти
                        </button>
                        ';
                }
                ?>
            </li>
        </ul>

    </header>
</div>

<body>

<section class="border p-4 container text-center mb-4 rounded-5">

    <!--SESSION MESSAGE-->
    <p>
        <?php
        if ($_SESSION['message']){
            echo $_SESSION['message'];
            unset($_SESSION['message']);
        }
        ?>
    </p>


    <?php
    switch (date('M')){
        case 'Jan':
            $month = 'Январь';
            $days = 31;
            break;
        case 'Feb':
            $month = 'Февраль';
            $days = 28;
            break;
        case 'Mar':
            $month = 'Март';
            $days = 31;
            break;
        case 'Apr':
            $month = 'Апрель';
            $days = 30;
            break;
        case 'May':
            $month = 'Май';
            $days = 31;
            break;
        case 'Jun':
            $month = 'Июнь';
            $days = 30;
            break;
        case 'Jul':
            $month = 'Июль';
            $days = 31;
            break;
        case 'Aug':
            $month = 'Август';
            $days = 31;
            break;
        case 'Sep':
            $month = 'Сентябрь';
            $days = 30;
            break;
        case 'Oct':
            $month = 'Октябрь';
            $days = 31;
            break;
        case 'Nov':
            $month = 'Ноябрь';
            $days = 30;
            break;
        case 'Dec':
            $month = 'Декабрь';
            $days = 31;
            break;
    }

    $first_day = date('N');
    $k = date('d');
    while ($k != 1){
        $k--;
        $first_day--;
        if($first_day == 0){
            $first_day = 7;
        }
    }

    $first_day--;
    ?>
    <span class="fs-3 under_table_month"><?php echo $month?></span>

    <br><br>

    <div class="events_all" style="display: flex">

        <div class="products">
            <div class="product week_day">ПН</div>
            <div class="product week_day">ВТ</div>
            <div class="product week_day">СР</div>
            <div class="product week_day">ЧТ</div>
            <div class="product week_day">ПТ</div>
            <div class="product week_day">СБ</div>
            <div class="product week_day">ВС</div>

            <?php

            $cell = '<div class="product"></div>';
            for($i = 0; $i < $first_day; $i++){
                echo $cell;
            }

                for($i = 0; $i < date('t'); $i++){
                echo "<input class='product product_live ";
                if (in_array($i+1, $days_with_events)){
                    echo 'there_is_event_today';
                }
                echo "'type='button' value='", ($i+1),"' onmouseover='viewDiv(" . '"div'.($i+1) .'"' . ")'>";

            }

            ?>
        </div>

        <div class="events_information">
            <span class="fs-4">События:</span>

            <?php

                for($i = 1; $i < date('t'); $i++){

                    echo
                    '<div id="div' . $i . '" class="product_info not_hovered">';

                    foreach ($events as $value => $key){
                        if($i == $key[0][0]){
                            echo '<div class="event_info"> <h5>' . $key[0][1] . ': </h5>' . $value . '<br>' . $key[0][2] . '</div><hr>';
                        }
                    }

                    echo
                    '</div>';



                }

            ?>

        </div>

    </div>
    <!--CheckBox of Events-->

</section>
    <?php echo $footer1; ?>
</body>
<?php
//      ADD EVENT BUTTON
if ($_SESSION['user']){
    echo '
                    <div class="under_header">         
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal4">
                            Добавить мероприятие
                        </button>
                    </div>
                    ';
}
//      DELETE EVENT IF ADMIN
if ($_SESSION['user'] == 'admin'){
    echo '
                <form action="assets/sql/delete_event.php" method="post">
                    <button class="btn btn-primary" style="display: flex; margin-bottom: 1em;" type="submit">Удалить мероприятие</button>';
    foreach ($events_before_fixing as $value) {
        echo '
                            <div style="display: flex; border: black 1px solid; padding: 10px; margin-bottom: 20px;" >
                                <input type="checkbox" class="large_checkbox form-check-input" name="' . $value['event_id'] . '" value="' . $value['event_id'] . '">
                                <div style="padding: 20px; text-align: left; margin-left: 10px; class="check_box">
                                    <span>' . $value['title'] . ', ' . $value['org_id'] . '</span>
                                    <br>';
        switch ($value['weekday']) {
            case 1:
                echo 'Понедельник';
                break;
            case 2:
                echo 'Вторник';
                break;
            case 3:
                echo 'Среда';
                break;
            case 4:
                echo 'Четверг';
                break;
            case 5:
                echo 'Пятница';
                break;
            case 6:
                echo 'Суббота';
                break;
            case 7:
                echo 'Воскресенье';
                break;
        }
        echo '          </div>
                            </div>';
    }
    echo '</form>';
}
//      DELETE EVENT IF ORGANIZER
if ($_SESSION['user'] == 'organizer'){
    echo '
                <form action="assets/sql/delete_event.php" method="post">
                    <button class="btn btn-primary" style="display: flex; margin-bottom: 1em;" type="submit">Удалить мероприятие</button>';
    foreach ($events_for_orgs as $value) {
        echo '
                <div style="display: flex; border: black 1px solid; padding: 10px; margin-bottom: 20px;" >
                    <input type="checkbox" class="large_checkbox form-check-input" name="' . $value['event_id'] . '" value="' . $value['event_id'] . '">
                    <div style="padding: 20px; text-align: left; margin-left: 10px; class="check_box">
                        <span>' . $value['day'] . '.' . date('m') . ' ' . $value['title'] . '</span>
                        <br>    
                        <span>' . substr($value['time'], 0, 5) . '</span>
                    </div>
                </div>
                        ';
    }
    echo '</form>';
}

?>

<?php
echo $modal_register;
echo $modal_autorization;
echo $modal_exit;
echo $modal_add_event;
?>
</html>

<script>
    function viewDiv(id){
        var elems = document.getElementsByClassName('not_hovered');
        for (var i=0;i<elems.length;i+=1){
            elems[i].style.display = 'none';
        }
        document.getElementById(id).style.display = "block";
    };

</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
