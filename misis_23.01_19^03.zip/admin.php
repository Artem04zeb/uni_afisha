<?php
session_start();

//assets
require_once 'assets/blocks_html/blocks.php';
require_once 'assets/sql/filling_of_events.php';
require_once 'assets/sql/get_orgs.php';
require_once 'assets/sql/get_requests.php';


if ($_SESSION['user'] != 'admin'){
    header('location: index.php');
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="vieport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style/css.css">
    <link rel="stylesheet" href="assets/style/small_screen.css">

    <title>MISIS АФИША</title>
</head>
<!-- HEADER -->
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">
        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
            <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"></use></svg>
            <span class="fs-3">MISIS АФИША</span>
        </a>

        <ul class="nav nav-pills">
            <li class="nav-item">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal3">
                    Выйти
                </button>
            </li>
        </ul>
    </header>
</div>

<!-- BODY -->
<body>

<section class="border p-4 container text-center mb-4 rounded-5">
    <div class="admin_container">
        <!--ЗАЯВКИ-->
        <form class="admin_form" method="post">
            <p class="display-6">Заявки</p>
            <div class="admin_requests_buttons">
                <button formaction="assets/sql/allow_to_be_org.php" class="btn btn-primary admin_button" type="submit">Одобрить выбранную заявку</button>
                <button formaction="assets/sql/delete_request.php" class="btn btn-primary admin_button red_admin_button" type="submit">Удалить выбранную заявку</button>
            </div>

            <?php
            foreach ($requests as $value) {
                    echo '
                            <div style="display: flex; border: black 1px solid; padding: 10px; margin-bottom: 20px;" >
                                <input type="checkbox" class="large_checkbox form-check-input" name="'.$value['id'].'" value="'. $value['id']  .'">
                                <div class="admin_checkbox_text">
                                    <span> id:' . $value['id'] . ', ' . $value['fname'] . ' ' . $value['lname'] . ', ' . $value['email'] . '</span>
                                    <br>
                                    <span>'.$value['organization'].'</span>
                                </div>
                            </div>
                        ';
                }
            ?>
        </form>

        <!--Организаторский состав-->
        <form class="admin_form" method="post">
            <p class="display-6">Организаторский состав</p>
            <button formaction="assets/sql/delete_org.php" class="btn btn-primary admin_button red_admin_button" type="submit">Удалить выбранного организатора</button>
            <?php
            foreach ($orgs as $value) {
                echo '
                            <div style="display: flex; border: black 1px solid; padding: 10px; margin-bottom: 20px;" >
                                <input type="checkbox" class="large_checkbox form-check-input" name="'.$value['id'].'" value="'. $value['id']  .'">
                                <div class="admin_checkbox_text">
                                    <span> id:' . $value['id'] . ', ' . $value['fname'] . ' ' . $value['lname'] . ', ' . $value['email'] . '</span>
                                    <br>
                                    <span>'.$value['organization'].'</span>
                                </div>
                            </div>
                        ';
            }
            ?>
        </form>
    </div>

    <!-- Modal EXIT -->
    <?php echo $modal_exit;?>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>

<?php echo $footer1; ?>

</html>